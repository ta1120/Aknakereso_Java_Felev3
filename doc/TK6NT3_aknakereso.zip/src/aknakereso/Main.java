package aknakereso;

public class Main /*A program indito osztalya*/
{
	
	public static void main(String[] args)
	{
		@SuppressWarnings("unused")
		GameFrame jatek;
		jatek = new GameFrame();
	}

}
